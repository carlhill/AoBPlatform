# Handoff: AoBPlatform onboarding surfaces

**Revision 2 · 22 August 2026.** Rebuilt against `PRACTITIONER-IDENTITY-RULES.md` and `IDENTITY-STRENGTH-DESIGN.md`. If you have revision 1, discard it — passkey recovery ran through the practice there, which is now explicitly wrong.

## Overview

Three staff-facing surfaces of AoBPlatform, drawn as annotated wireframe storyboards:

1. **Practice onboarding hub** (M13) — application, the three gates, the checklist hub, locations, practitioners, AHPRA check, affiliations, capture-ready.
2. **Practitioner onboarding hub** (M13 / REQ-PKI) — the enrolment ceremony, passkey enrolment, accepting affiliations, registration record, recovery.
3. **Platform operator admin** — operations dashboard, rule-set versions, basic service description mapping ingest, vault chain monitor, validation queue, tenant flags, audit log.

A fourth document, the **UI map**, inventories all eight surfaces the product needs and records which are drawn. The practice console (M12), kiosk (C2), remote capture link, patient portal and public s 65C tester are **not** drawn.

## About the design files

The files in `wireframes/` are **design references created in HTML** — annotated drawings of intended layout, information hierarchy and behaviour. They are not production code and nothing in them should be copied into the app.

The target environment already exists: `apps/web` is **Next.js + Radix**, WCAG 2.2 AA, with all user-facing strings in the string table (`apps/web/app/strings.ts`, REQ-LANG-01). Recreate these layouts there, using Radix primitives and the string-table discipline. Do not lift the wireframe CSS, the `.wb` / `.wbtn` / `.chip` classes, or the greyscale palette.

## Fidelity

**Low-fidelity.** Deliberately greyscale, with no brand colour, no icons and no final typography. Use them for layout, sequence, states, copy intent and — most importantly — the annotations. Apply the app's own design system for styling.

The exception: **the copy is considered.** Where a wireframe states a rule to the user ("There is no password to choose", "A number the applicant chose proves only that they answer their own phone", "checked against the s 65C data set"), treat the wording as a starting draft rather than filler, and put it in the string table.

## How to read a frame

Each frame is one screen in a browser window frame, followed by a numbered annotation grid. Pins (`1`, `2`, `3`…) inside the screen point at the element the annotation describes. Every annotation carries the requirement it comes from in the margin — `REQ-PKI-01`, `FR-1.8`, `rule 11`, `D-01`, and so on. **The annotations are the specification.** The boxes are only where things sit.

Resolve requirement IDs the way `CLAUDE.md` §1 says: capabilities in `AoB_requirements.md`, statutory detail in `aob-requirements.md`, module and FR behaviour in `aob-functional-requirements.md`, ADRs in `aob-solution-architecture.md`.

## Screens

### Practice onboarding — `wireframes/onboarding-storyboard.html`

Eleven frames. Route prefix `/practice/<slug>`; the hub owns `/setup`, and practitioners sit at `/practitioners`.

| # | Screen | Route | Purpose |
|---|---|---|---|
| 01 | Apply — entity details | `/apply` | Practice name (legal **or** trading), ABN, head office, repeatable proof-of-practice rows, two named contacts |
| 02 | ABN checksum refusal | `/apply` | Inline, submit dead, nothing sent |
| 03 | ABR says CANCELLED | `/apply/gate` | Blocking modal, one reason, two real ways forward |
| 04 | ABR unreachable | `/apply/attest` | Manual attestation panel; same gates run on typed values |
| 05 | Reviewer dossier | `/review/<slug>` | Entitlement check, **identity checklist and score**, decision. See both notes below |
| 06 | Onboarding hub | `/setup` | Five cards, any order, gates enforced |
| 07 | Locations | `/setup/locations` | Add, then confirm-and-activate as a separate attributed action |
| 08 | Practitioners | `/practitioners` | Pre-register, directory lookup by exact AHPRA number only |
| 09 | AHPRA register check | `/practitioners/<id>/ahpra` | Type what the register says; repeatable registration types |
| 10 | Affiliations | `/setup/affiliations` | Practitioner × location; provider number lives here |
| 11 | Capture-ready | `/setup` | Terminal state; hands off to the practice console |

**Layout rules that matter more than the pixels:**

- **The gate ledger.** Three rows — ABN checksum, ABR, named human — present on every application state with per-row pass / fail / not-run marks. Never a single aggregate tick.
- **Refusal grammar.** Inline for the checksum (a typo), blocking for ABR status and name mismatch (the entity is wrong), a dossier note for an unverifiable applicant (a judgement), and an attestation panel when the ABR is unreachable (degrade, never block). Applying the wrong one is the most likely mistake here.
- **Cards summarise; pages hold lists.** Every hub card caps at roll-up chips plus two rows and a "+n more", with an "Open the … table →" action. Cards never scroll. The tables carry search, filters and a result count — a multi-site organisation can have hundreds of affiliations.
- **Worst row first.** Each card promotes its exception above its healthy rows rather than sorting alphabetically.
- **Head office is listed but disqualified** as a place of practice unless explicitly ticked.
- **Approve is dead while a gate fails; reject never is.** The asymmetry is deliberate.
- **Structured addresses everywhere** — line 1, line 2, suburb, state, postcode, country. Never a single line. Every locality match downstream depends on it, and it is item 1 in the identity-strength build order.
- **The invitation cap.** A practice states its practitioner count at onboarding; the allowance is that number plus a margin, with a default ceiling, counted against active **plus invited** so ordinary churn does not exhaust it. **Hide the arithmetic, surface the wall** — never tell a user how many invitations remain (that hands an attacker the budget), but a practice at the ceiling must be told the ceiling exists and how to raise it. A silent failure is indistinguishable from a broken platform, and the first people to hit it will overwhelmingly be legitimate practices that grew. Repeatedly pushing at the cap is itself a negative signal.

**Identity strength — frame 05's checklist (`IDENTITY-STRENGTH-DESIGN.md`):**

- **Points attach to verified checks, never to entered data.** Typing an HPI-O scores nothing; an HPI-O confirmed with the Healthcare Identifiers Service is a STRONG check. If entering a credential earned a point, a fraudster would type ten invented ones.
- **The gate is two-part:** `total >= 6 AND at least one STRONG check passed`. Without the second clause, eight trivial signals clear a threshold of six. Independence beats count — five facts from one submitted document are one fact.
- **Four outcomes, not two:** `passed` (full weight), `failed` (0, may be negative), `not_applicable` (0, **excluded from the denominator**), `could_not_complete` (0, **reason required**). A sole trader has no manager to call — that is not applicable, not failed. Collapsing them corrupts the score and punishes small practices for being small. "The ABR was down" and "they refused" are different facts about an applicant.
- **Weights:** STRONG / MODERATE / WEAK / NEGATIVE, recorded as they were at the time.
- **Soft enforcement now, hard later** — `IDENTITY_ENFORCEMENT=soft|hard`. Every check runs, is scored and is stored from day one; nothing is refused on score alone. You cannot calibrate a threshold you are already enforcing.
- **The score is stored AND recomputed.** Stored with its scoring version at decision time, because that is evidence of what the reviewer saw. Recomputed live, because that is current risk. Changing weights must never silently rewrite history.
- **The applicant never sees the score, the weights or the threshold.** They are told what is missing in plain terms — "we could not confirm your HPI-O" — never where they sit.
- **Checks are append-only and versioned**, like rule sets and the BSD mapping. A check performed under catalogue v3 must read as v3 forever.
- **The check worth adding most:** compare the AHPRA principal place of practice (suburb and postcode) against the practice address. Free, automatable, and the only check that ties **a person to a place** rather than verifying one of them.
- **Profession versus asserted provider type.** If a practice affiliates someone as `general_practitioner` whose register record says *Nurse*, flag it.

**Frame 05 specifics, reconciled against `apps/core/src/organisations/`:**

- `decision` writes `validated` | `rejected`. Decide whether the button says Approve or Validate; the API value does not change.
- `entitlementMethod` ∈ `phone_call` | `domain_match` | `hpio` | `document` | `none`. Required to approve, not to reject.
- `entitlementNumberSource` ∈ `nhsd` | `practice_website` | `public_directory` | `application_form` | `other`. Choosing `application_form` degrades the check to nothing and the field says so inline.
- A rejection **must** carry a note, and the note **must not** disclose that an ABN is already registered — the service refuses it, because that turns rejection into customer enumeration.
- The decision is single-shot and race-guarded: pending state is re-checked inside the write, and the losing reviewer is told who approved it and when.
- `reviewerName` is never "system" and never blank.

### Practitioner onboarding — `wireframes/practitioner-storyboard.html`

Nine frames in two halves. Frames 01–02 are practice-side, 03–08 happen in the practitioner's own session, and 09 is an operator surface.

| # | Screen | Route | Purpose |
|---|---|---|---|
| 01 | Enrolment ceremony | `/practitioners/<id>/ceremony` | The three checks, by a named human, before any key exists |
| 02 | No ceremony, no key | `/practitioners/<id>` | Blocking refusal listing the missing checks |
| 03 | The invitation | `id.…/enrol?token=` | "There is no password to choose"; shows what was attested about them |
| 04 | Enrol the passkey | `id.…/enrol/key` | Native OS prompt, unstyled; another-device path |
| 05 | My practices | `/me` | Invitations waiting; accept, decline, notice |
| 06 | Accept an affiliation | `/me/invitations/<slug>` | Renders the provider block as it will appear on the agreement |
| 07 | My registration | `/me/registration` | What the platform holds, and who attested it |
| 08 | Locked out — suspension | `/me/security` | Passkey list; suspension as the fast, low-bar, grants-nothing path |
| 09 | Recovery | `ops.…/recovery/<id>` | **Operator surface.** Three proofs, cooling-off, notify every practice |

**Rules encoded in these frames, from `apps/core/src/identity/` and `packages/domain/`:**

- `RecordCeremonyDto` — `ahpraNumber`, `ahpraRegistrationCurrent` (attested **current**, not merely present), `providerNumber` **plus** `providerNumberLocation` (a provider number is a property of a practitioner at a place), `providerNumberVerified`, `personVerificationMethod` ∈ `video` | `in_person` **only**, `verifiedByName` (never "system"), optional `evidenceNote`, optional `steppedUp`.
- Self-attestation is blocked. A practitioner cannot perform their own ceremony.
- Ceremonies are **append-only** — a trigger refuses edits and deletes, including from the test suite. A mistake is corrected by recording a new ceremony, which is itself visible. Say this on the screen that writes it, before submission.
- No ceremony (or a stale one) ⇒ the invite endpoint refuses **before** touching the identity provider. Nothing is half-created, and the copy says so.
- Accounts hold **no password**. The emailed action link is the only way in, because the login flow needs a passkey they do not have yet.
- Affiliation statuses: `invited` | `active` | `ending` | `ended` | `rejected`. Only the practitioner may accept, decline or withdraw; there must be no screen anywhere that lets a practice do it for them.
- Notice runs **before** the end date — the affiliation stays active and capture continues until then. Either side may give notice.
- AHPRA deregistration is immediate, across every affiliation, with no notice period.
- Re-enrolment is **recovery**: a new ceremony with `steppedUp`, logged as recovery rather than a routine invitation. There is no email-only path back in.
- Do not restyle the OS passkey prompt. The wireframe deliberately leaves it as a placeholder.

**Rules changed 21–22 August. These are the ones most likely to be built wrong:**

- **Accepting an affiliation requires the passkey.** The invitation is an offer; the acceptance is an act, and acts are signed. Without it the invitation-only rule leaks — a practice could invite and then click accept on a screen nobody authenticated to, which is a practice creating an affiliation in a doctor's name. Not yet enforced (`AUTH_ENFORCE=false` trusts a practitioner id in the path); it is a release gate, not a design choice.
- **Two authenticators are mandatory at enrolment**, not encouraged — phone plus laptop, or a security key. Plus one-time recovery codes issued once and stored offline. This is FIDO's own guidance and it is what stops most recovery requests existing.
- **Suspension and recovery are different operations on different bars, and never share a path.** Suspension: performed on request, low bar, immediate, grants nothing — a practitioner who has lost their key or suspects a practice is using their provider number gets affiliations suspended today. Recovery: full re-proofing, deliberately slow, grants everything.
- **Recovery is performed by AoBPlatform, never by a practice.** A locked-out practitioner must not depend on the practice they may be escaping. Requires all three of: video call matched against the AHPRA register entry, government photo ID matched live with liveness detection, and demonstrated control of their AHPRA portal account. Plus the practitioner-owned email recorded at invitation, a mandatory cooling-off period before the new key works, and notification to **every** affiliated practice.
- **Do not collect date of birth or home address as recovery answers.** That is knowledge-based authentication, which is broken — the data is in every breach. A database of doctors' home addresses is also a target with a duty attached, and AHPRA itself lets practitioners suppress their principal place on safety grounds. Collect DOB only if it will be matched against an authoritative source (DVS), never asked as a question, and say so in the collection notice.
- **Capture at enrolment instead:** full legal name as it appears on photo ID, and a hash of the AHPRA registration certificate then current. Recovery should have something to match, not something to ask.
- **Uploaded artefacts are attacker-supplied.** Hash on upload, hash to the vault, bytes to object storage. Store as opaque bytes, serve `Content-Disposition: attachment`, never render inline, never trust the declared content type.

### Operator admin — `wireframes/operator-storyboard.html`

Eight frames. Separate host (`ops.…`), left rail with two groups — content we version, and the fleet.

| # | Screen | Route | Purpose |
|---|---|---|---|
| 01 | Operations dashboard | `/` | Chain, rule set, ingest, queue depth; verbal-capture fuse countdown |
| 02 | Rule sets | `/rule-sets` | Draft, diff, publish (two approvers), rollback as a row action |
| 03 | Mapping ingest | `/mapping` | Quarterly schedule as the spine; failure state with the previous version pinned |
| 04 | Evidence vault | `/vault` | Chain status, event stream, crypto-shredding, legal hold |
| 05 | Validation queue | `/queue` | Gate columns are the queue |
| 06 | Practices | `/practices/<slug>` | Feature flags with attribution; RLS shown as evidence, not configuration |
| 07 | Audit log | `/audit` | Identifier **types** only; export as an evidence bundle |
| 08 | Identity strength | `/identity` | Two dashboards, soft/hard switch, provider-number conflicts, decay |

**Rules encoded here:**

- **Never** render "certified", "approved", "accredited" or "government-approved" about our forms. Permitted: "checked against the s 65C data set", "self-assessment". The constraint is stated at the top of the rule-sets screen because that is where it would first appear.
- Rule sets and BSD mappings are versioned content; every stored agreement records both versions. No threshold is hardcoded, and a rule with no version cannot be published.
- Publishing a rule set needs **two named approvers**. Rollback is a row action, not an incident procedure.
- The BSD mapping updates quarterly on 1 Jan, 1 Mar, 1 Jul, 1 Nov, published as XML/CSV on MBS Online — a **separate** download from the MBS XML fee file. A schema change makes the ingest **refuse rather than guess**, and the previous version stays pinned. Stale is not the same as invalid, and the banner must say both.
- The pre-agreement scope test is **containment, not equality**.
- The vault has **no update and no delete endpoint**. Deletion is crypto-shredding plus a tombstone event. Tombstones appear in the stream as events, not gaps.
- Retention runs **2 years from the date of the related claim**, not the service date; legal hold suspends scheduled deletion and is always visible with who set it.
- Verbal capture works until **30 June 2027**, then auto-disables and needs an explicit override with a reason. The countdown and the per-practice usage table are home-screen objects.
- `enduring.registration` is a dead switch with a stated reason — no portal, form or API has been published (D-11).
- Audit rows carry identifier **types** and outcomes, never values (rule 9). No PII in logs or error messages.
- Nothing on the tenant screen may prevent a patient being seen or billed (rule 8).
- **Two identity dashboards, operator-only.** Practices: score, band, which checks failed or could not complete, artefact count, time in queue — *which applications are stuck, and on what?* Practitioners: score, days since the register was last sighted, restrictions, affiliation count and velocity — *whose verification is going stale, and who is moving unusually?*
- **The "would fail under hard" column is the point of soft mode.** It shows live what hard enforcement would cost. That number decides when to flip the switch, and it is invisible unless you run soft first.
- **Practitioner strength decays.** A registration verified in January says little in December. Show the score dropping, not the value it had at enrolment.
- **Provider-number conflict detection.** We hold (practitioner × location × provider number). One number at two unrelated locations, or two practitioners claiming one number, is structurally impossible. **No single practice can see this; only a platform spanning practices can** — and the provider number is the artefact we cannot verify and the one fraud turns on.
- **Deregistration propagates.** Learn once, stop them at every affiliated practice within the hour.
- **Practitioner suspension is an operator action**, on a low bar, because the practice may be the adversary.
- **No risk score about an individual practitioner is ever shared with a practice.** That is a credit score for doctors, with every accuracy and fairness problem credit scoring has, applied to livelihoods. And no practitioner-level data is sold.
- Secondary use is decided **before** the first application is taken and stated in the collection notice — workforce analytics and sector reporting are a secondary purpose under APP 6, and retrofitting consent is far harder than collecting it correctly.

## Interactions & behaviour

- **Dead-until-valid.** Primary actions are disabled until the payload validates; blocked states are unreachable rather than warned about. This is the same discipline as the signature control, which cannot enable until the agreement payload passes the rules engine (REQ-REG-06 — signing a draft is the criminal offence in this regime).
- **Attribution at the point of action.** Every approve, activate, invite, publish, notice, override and attestation captures a named person in the same panel as the button.
- **Version stamps are displayed, not implied.** Rule set and mapping versions appear on the dashboard, on the capture-ready state and in every audit row.
- **No hover-only information.** Everything a reviewer or operator needs is visible without pointing at it.
- Two-step add + separate attributed activation for locations. New locations are `inactive` and cannot be affiliated to.
- Modals are used only for blocking refusals (frames 03, 02-practitioner) and the native passkey prompt.
- No animation is specified. Nothing here should move.

## State

Not drawn as a state machine, but these are the states the screens assume:

- **Organisation:** `pending` → `validated` | `rejected`. Approved organisations leave the queue; search by name, trading name or ABN to return to one.
- **Location:** created `inactive` → `active` on confirm-and-activate. Only active locations accept affiliations.
- **Affiliation:** `invited` → `active` | `rejected`; `active` → `ending` (notice given, still capturing) → `ended`. Deregistration jumps straight to ended everywhere.
- **Practitioner identity:** no account → ceremony recorded → passkey-only account created → invited → enrolled. Recovery re-enters at "ceremony recorded" with `steppedUp`.
- **Rule set / mapping:** `draft` → `in force` → `superseded`, with rollback; mapping adds `failed` and `not yet published`.

Data the screens need: gate results per application, entitlement record, ceremony record, affiliation list per practitioner **and** per practice (scoped differently), chain verification status, ingest job history, flag state with attribution, audit rows.

## Design tokens

The wireframes intentionally use a greyscale subset. **Do not port these values** — use the app's own system. Listed only so the drawings can be read.

- Ink `#1d1f20`, page `#fbfbfc`, chrome `#e7e7ea`, borders `#b7b7ba` / `#98989b`, muted text `#5d5d60` / `#7a7a7d`.
- Annotation pins are the one non-grey: `#416180`.
- Type: Barlow Condensed for headings, Barlow for body; 12.5px body inside screens, 10–11px for monospace and uppercase labels.
- Spacing: 12 / 14 / 18 / 20 / 28 / 32px. Square corners throughout, hairline 1px borders.
- Canvas: 1440px wide, staff desktop only.

## Assets

None. No images, no icons, no logos. Photographic and native-UI regions are striped placeholders with a monospace label saying what belongs there.

## Files

```
wireframes/ui-map.html                  the eight surfaces, shared patterns, refusal grammar
wireframes/onboarding-storyboard.html   practice onboarding, 11 frames
wireframes/practitioner-storyboard.html practitioner onboarding, 8 frames
wireframes/operator-storyboard.html     operator admin, 7 frames
wireframes/wireframe.css                the wireframe vocabulary (reference only, do not port)
styles.css                              the Industry design-system token sheet the docs are drawn on
screenshots/ui-map.png                  full-page render of each document, annotations included
screenshots/practice-onboarding.png
screenshots/practitioner-onboarding.png
screenshots/operator-admin.png
```

Open `wireframes/ui-map.html` first; the three storyboards cross-link from its nav strip. The screenshots are full-page renders of the same four documents, for reading without a browser — the HTML is the reference.

## One marketing line not to cross

**AoBPlatform prevents fraudulent CONSENT RECORDS, not fraudulent CLAIMS.** We are not in the claim path: a practice that bills Medicare without capturing consent through us is invisible to this platform, and no feature changes that. Related premise to keep straight — Medicare does not bill on the AHPRA number. Claims carry the **provider number**, issued per practitioner per location, not public and not derivable from the register, and payment lands in the bank account registered against it. Copying an AHPRA number off the public register yields nothing billable.

## Out of scope for this handoff

Practice console (M12), kiosk (C2), remote capture link, patient portal (M8), public s 65C tester. The UI map records what each needs, but no layouts exist yet.

Also unresolved and deliberately not designed around: **D-01** (Medtech write-back mechanism — the connector card promises a download and nothing more) and **D-11** (Services Australia enduring registration — dead flag, stated reason). Do not build against either.
