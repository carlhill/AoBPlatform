# Handoff: AoBPlatform UI — kiosk capture, console, and five further surfaces

## Overview

Design references for the AoBPlatform consent-and-compliance product (Medicare Assignment of Benefit). Covers the Phase 1 patient-facing capture surface at high fidelity and seven surfaces at wireframe level, with the regulatory hard rules expressed as UI constraints rather than notes.

Target repo: `carlhill/AoBPlatform` (`main`). Web surfaces are Next.js + Radix in `apps/web`; the kiosk is Expo/React Native in `apps/kiosk`. All user-facing strings go through the string table (`apps/web/app/strings.ts` pattern, REQ-LANG-01) — none inline.

## About the design files

The files in this bundle are **design references written in HTML**. They show intended layout, type, colour, copy and states. They are not production code to copy. Recreate them in the repo's existing environment — Next.js + Radix for console/portal/tester, Expo for the kiosk — using its established patterns. Do not introduce a new UI library.

`.dc.html` files open directly in a browser. `support.js` is their runtime and is irrelevant to implementation. `_ds/industry-.../styles.css` is the token sheet the hi-fi screens are built on; port its variables into the app's theme layer rather than linking it.

## Fidelity

- **High fidelity** — `AoB Kiosk.dc.html` and `AoB Console.dc.html`. Final colours, type, spacing, copy, states. Recreate closely. Screens are drawn at 1:1 (1024×768 landscape, 820×1180 portrait).
- **Low fidelity** — `AoB Wireframes.dc.html` (options `1a`–`1h`). Structure and flow only; apply the same token set when building.
- Remaining wireframe-only surfaces: reconciliation queue (`1d`), portal verify-a-message and termination (`1e`), public tester (`1f`), onboarding (`1g`), enduring + 89AA (`1h`).
- **One log, two audiences**: `M-1` and the Messages tab of `P-1` are the same dispatch records rendered for different readers. Build them off one query and one string table, not two features.

## Screens

### Kiosk (Expo, offline-first, both orientations) — hi-fi

Shared chrome on every kiosk screen: header with practice name (Barlow Condensed 600, 22–26px) and location line (Barlow 15px, 55% ink), a step tag top-right; 1px `--color-divider` rule above a footer carrying `AoBPlatform` bottom-left (Barlow Condensed 600, 11px, uppercase, 0.14em tracking, 55% ink) and one line of context bottom-right (14px). Content padding 32–36px. Frames and inset panels use the blueprint treatment: 1px `--color-divider` border, square corners, four `+` registration marks.

| Id | Screen | Purpose | Notes |
|---|---|---|---|
| K-1 | Idle | Invite check-in | Centred stack: h1 64px, 22px sub, primary button 24px / 72px min-height. Footer carries language chips + read-aloud. |
| K-2 | Verification (M3) | Prove identity before anything renders | Two-column: form (2-up then full-width field, inputs 64px / 20px) + REQ-VER-02 annotation panel. No Medicare field, no setting that adds one. |
| K-2b | Mismatch → lockout | Fail states | Generic "Some details don't match" — never names the wrong field. Lockout routes to reception; care unaffected. |
| K-5 | Who is signing | Assignor branch | Two 76px choice buttons, then assignor detail panel. Age gates (patient 14+ self-assign, assignor 18+) and the practice-staff hard block with its exact refusal copy. No capacity question. |
| K-3a | Particulars as native screen | Read and validate | Locked particulars grid + right rail listing what is missing, with the sign control **disabled and naming the count**. |
| K-3b | Particulars as PDF/A artefact | Same step, document view | White artefact page with hash line in the footer. Both variants are compliant; recommendation on the panel: native screen for signing, PDF one tap away as "view the document". |
| K-4 | Signature | Capture | Validated banner, white pad with signature rule, Clear + "I agree and sign" (68px). Tap-to-approve variant offered where signing on glass is hard. |
| K-6 | Complete | Copy delivery | Optional portal activation, never required. Returns to idle after 20s. |
| KP-1..3 | Portrait | Same flow | Identical field set, stacked, never reduced. KP-2 adds the read-through progress gate. KP-3 shows the offline path. |

### Console, desk and remote link (Next.js + Radix) — hi-fi

Shared chrome: `.nav` header (practice name 18px Barlow Condensed 600 + location line 13px) with a chain-status tag and the signed-in identity tag; 196px left column grouped Today / Records / Practice with a go-live stub pinned to the bottom; content padding 26px 30px; a footer rule with `AoBPlatform` bottom-left and one line of context bottom-right. Right rails are 400–420px and hold annotation panels. Canvas 1440×900.

| Id | Screen | Notes |
|---|---|---|
| M-1 | Practice correspondence | Every message sent in the practice's name: purpose, channel, delivery state, per-message cost. Filter segment plus a "what we sent" panel with the exact template text. 89AA rows carry no resend-to-chase action; confidential visits show as suppressed before a message exists; STOP applies across all channels. |
| P-1 | Patient portal (390×844, three tabs) | Agreements across every practice; Messages — the same correspondence log from the patient's side, same wording and timestamps; Access — mirror of the staff access log, plus assignor nomination management. |
| C-1 | Today | Three task cards, then a 4-up metric strip, then two panels — evidence health and our own SLA performance shown to the practice. No charts. |
| C-2 | Go-live checklist | Six rows with evidence text and a status word; "Go live" disabled while one requirement is outstanding; test-mode explainer states what still works. |
| C-3 | Settings | Identity check (approved six, four selected, floor 3), channels and reminders, follow-up bands (thresholds editable, order fixed), plus a "what you cannot change" panel. |
| A-1 | Agreements list | Filter segment, 8-column table, channel and type as words; voided rows stay listed. |
| A-2 | Artefact detail | Hash re-verify banner, the artefact itself, the event trail (verify → render+hash → sign → write-back → copy → anchor), and the access log the patient also sees. No edit, no delete. |
| A-3 | Hash mismatch | Document withheld, both hashes shown, integrity incident action. Must exist. |
| S-1 | Desk verification | Tick identifier *types* checked, staff attestation under passkey, then the four signing paths. |
| S-2 | Verbal fallback | Risk-flagged version and the post-1-July-2027 disabled version side by side, with principal override + written reason. |
| S-3 | Paper | Pre-filled print with matching code and hash line; scan-back drop zone plus two attestations; hand-altered particulars void the sheet. |
| PR-1 | Practitioner view | Own patients only; four stat cards; settings/staff/billing absent by role. |
| L-1 | Remote link landing (390×844) | Content-blind challenge, verified state, and five terminal states: done, expired, mismatch, locked, declined. |

### Other surfaces (wireframe)

Console `C-1..C-3` (`1c`), reconciliation queue `R-1..R-3` (`1d`), patient/assignor portal `P-1..P-3` (`1e`), public s 65C tester `T-1..T-2` (`1f`), onboarding `O-1..O-3` (`1g`), enduring + 89AA `E-1..E-2`, `N-1` (`1h`). Screen-by-screen states are listed in `UI-BUILD-PLAN.md` §3.

## Interactions and behaviour

- **Signature control**: takes the rules-engine validation result as a **required** prop with no default. Disabled renders the reason ("Sign — 2 details still needed"). No code path enables it from an invalid payload. Test: `signature_disabled_until_payload_valid`.
- **Verification**: 3 attempts, then lockout with practice notification and a staff-assisted unlock at the desk. Constant-time comparison; no partial-match disclosure.
- **Read-through gate** (portrait only): sign disabled until the particulars scroller reaches the end; progress bar reflects position.
- **Offline**: capture continues against the on-device rule set, queues encrypted, re-validates at sync. The UI states this plainly to the patient. Nothing blocks care (REQ-REC-04).
- **Cross-channel dedup**: completing any channel closes the others; reminders stop on completion, decline or STOP.
- **Hash re-verification**: any later display of an artefact re-verifies its hash and renders a failure state if it does not match.
- Transitions: 120–160ms ease-out on state change; no decorative motion on patient surfaces.

## Hard rules the UI must enforce

1. REQ-REG-06 — signature disabled until particulars validate and lock.
2. REQ-VER-02 — Medicare card number is not an identifier; approved set only (name, DOB, gender, address, patient record number, IHI). Non-configurable.
3. Guardrail language — a build-failing lint on "certified", "approved", "accredited", "government-approved" in user-facing strings. Permitted: "checked against the s 65C data set", "self-assessment".
4. Age gates — assignor acting for another 18+; patient 14+ may self-assign; no capacity control anywhere.
5. Practice-staff assignor hard block, with neutral refusal copy that does not name the rule.
6. Also carried through the designs: no practitioner signature field (C10); no dollar amount on any agreement artefact — benefit amounts appear only on 89AA notices (REQ-REG-04); verbal capture risk-flagged and auto-disabled 30 Jun 2027; 89AA surfaces carry no approval semantics and no chase action.

## State

Kiosk: `session {patientRef, verificationEventId}`, `attempt 1..3 | locked`, `assignor {isPatient, name, relationship, basis, ownChannel}`, `validation {rules[], blockingCount}`, `artefact {hash, ruleSetVersion, mappingVersion}`, `signature {vector, raster}`, `connectivity {online, queueDepth}`, `locale`. Every mutation emits its vault events through the outbox; the UI reports the event, never success on its own authority.

## Design tokens (Industry system)

Ground `#f2f2f3` · surface `#e9e9ea` · ink `#1d1f20` · accent `#5980a6` · divider `color-mix(in srgb, #1d1f20 16%, transparent)`. Accent ramp 100–900: `#eef6ff #d6ebff #b5d9fd #94bce3 #749dc4 #597ea3 #416180 #2c455d #1d2d3d`. Neutral ramp 100–900: `#f5f5f8 #e7e7ea #d4d4d7 #b7b7ba #98989b #7a7a7d #5d5d60 #424244 #2b2b2d`.

Type: Barlow Condensed 600 headings, Barlow 400/500/700 body. Kiosk scale — h1 56–64px, h2 40–42px, body 19–22px, labels 15px, footnote 14px. Console scale — h2 32px, h3 25px, body 15px, table 14px, kicker 11px uppercase 0.08em.

Spacing 3.4 / 6.8 / 10.2 / 13.6 / 20.4 / 27.2px. Radius 0 on cards, buttons, inputs, tags (square by system rule); 2/4/7px tokens exist for anything else. Shadows `--shadow-sm/md/lg`. Icons: Lucide at stroke-width 1.5. Focus: `2px solid var(--color-accent)`, offset 2px — never the browser default.

Accessibility: WCAG 2.2 AA on every patient surface. Secondary text uses `--color-neutral-700` (#5d5d60 — 6.0:1 on the #f2f2f3 ground); do **not** inherit the system's 55%-ink muted default for small text, which measures 3.64:1 and fails AA. Reserve muted for decorative text at 15px+. kiosk targets ≥ 56px (spec floor 44px); colour never the sole carrier of state — bands, rule results and checklist rows all carry a word.

## Assets

None. No photography, no logos. Practice logo is an optional slot in the kiosk header; the platform mark is text only.

## Files

- `AoB Kiosk.dc.html` — hi-fi kiosk, both orientations.
- `AoB Wireframes.dc.html` — seven surfaces, options `1a`–`1h`.
- `UI-BUILD-PLAN.md` — screen inventory, component inventory, build order, open items (D-01, D-11).
- `_ds/industry-.../styles.css` — token sheet the hi-fi screens use.
- `support.js` — runtime for the `.dc.html` files; not part of the implementation.
