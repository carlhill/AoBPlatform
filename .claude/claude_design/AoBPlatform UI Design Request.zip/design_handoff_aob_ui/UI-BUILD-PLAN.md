# AoBPlatform — UI build plan and screen spec
### For Claude Code · derived from CLAUDE.md, aob-functional-requirements.md, aob-solution-architecture.md, aob-build-plan.md
Wireframes: `AoB Wireframes.dc.html` (option ids `1a`–`1h` are referenced below).

---

## 1. Scope of this design pass

Seven surfaces wireframed. Hi-fi follows for the kiosk and the practice console — the two Phase 1 milestone surfaces (M1, mid-Dec 2026: design partner captures real agreements on tablet with staff on passkeys).

| Surface | Modules | Wireframe | Phase |
|---|---|---|---|
| Kiosk tablet capture | M2, M3 | `1a` landscape, `1b` portrait | 1 |
| Practice console | M12 | `1c` | 1 |
| Reconciliation / outstanding queue | M7 | `1d` | 2 |
| Patient & assignor portal | M8 | `1e` | 2 |
| Public s 65C tester | M4 | `1f` | 3 |
| Practice + practitioner onboarding | M1.A, M1.B | `1g` | 1 |
| Enduring lifecycle + 89AA notices | M5, M6 | `1h` | 4 |

Build order inside Phase 1 is unchanged from the build plan: vault → rules → domain core + adapter → verification → kiosk → console → onboarding. The UI work starts at "kiosk".

## 2. Branding model

Practice-led chrome, platform mark subordinate.

- Every patient-facing surface headers with **practice name + location** (the location matters: s 65C(5)(a) depends on place of practice).
- `AoBPlatform` appears once, bottom-left of the footer, at 9.5–10px, never in the header.
- Practice theming is limited to name, location line and optional logo. No practice-supplied colour — the chrome palette is fixed so that WCAG 2.2 AA contrast is provable across every tenant.
- Platform chrome palette: ink `#1c3f36`, accent `#5f8d7e`, tint `#d8e0da`, paper `#f7f8f7`, alarm `#c05a45`.

## 3. Screen inventory

### 3.1 Kiosk (Expo, offline-first, both orientations)
| Id | Screen | States to build |
|---|---|---|
| K-1 | Idle / check-in | idle, offline-with-queue-count, language switch, read-aloud on |
| K-2 | Verification (M3) | attempt 1–3, generic mismatch ("some details don't match" — never which), lockout + staff-assisted unlock, staff-verified variant |
| K-5 | Who is signing | patient self-assign (14+), assignor branch, staff-blocked, nomination conflict |
| K-3 | Locked particulars | validating, blocked with named reasons, valid, read-through gate (portrait), re-verify-hash failure |
| K-4 | Signature | empty pad, drawn, tap-approve variant, submitting, offline-queued |
| K-6 | Complete | copy delivery, optional portal activation, write-back queued |

### 3.2 Practice console (Next.js + Radix)
| Id | Screen | Notes |
|---|---|---|
| C-1 | Today | task-led: at most three actionable cards, then the REQ-MON-01 metric strip. No vanity charts. |
| C-2 | Go-live checklist | FR-1.7 rows; blocked until all pass; conformance statement download |
| C-3 | Settings | identifier set (floor 3), expiry, cadence, quiet hours, bands, languages, channels, verbal-fallback policy, sender ID |
| C-4 | Agreements list + detail | artefact view re-verifies the hash before display; access log |
| C-5 | Practitioners | invite, provider number per location, notice, deregistration |
| C-6 | Billing / usage | SMS spend in real time (REQ-SMS-06) |

### 3.3 Remaining surfaces
Queue `R-1..R-3`, portal `P-1..P-3`, tester `T-1..T-2`, onboarding `O-1..O-3`, enduring `E-1..E-2`, notices `N-1` — as drawn.

## 4. Hard rules that are UI-visible

Each becomes a component-level constraint plus a Playwright test, not a comment.

1. **REQ-REG-06 — signature disabled until particulars validate.** The sign control takes `validation` as a required prop with no default. Disabled state must name what is missing ("Sign — 2 details still needed"). There is no code path that renders an enabled control from an invalid payload. Test: `signature_disabled_until_payload_valid`.
2. **REQ-VER-02 — Medicare card number is not an identifier.** The verification field set is typed to the approved six. No configuration surface offers it. Test: `medicare_number_rejected_as_identifier`.
3. **Guardrail language.** Strings live in `apps/web/app/strings.ts` / the kiosk string table (REQ-LANG-01). A lint rule fails the build on "certified", "approved", "accredited", "government-approved" in any user-facing string. Permitted: "checked against the s 65C data set", "self-assessment".
4. **Age gates.** Assignor acting for another must be 18+; patient 14+ may self-assign. Enforced in the branch component and again server-side. The UI never asks staff to assess capacity — no capacity control exists.
5. **Practice-staff assignor hard block.** Assignor identity checked against the practice staff list; refusal copy is neutral and does not name the rule to the patient.
6. Also carried through the designs, unprompted but structural: no practitioner signature field anywhere (C10); no dollar amount on any agreement artefact — benefit amounts appear only on 89AA notices (REQ-REG-04); verbal capture risk-flagged and auto-disabled 30 Jun 2027; 89AA screens carry no approval semantics and no chase action; nothing blocks care (REQ-REC-04).

## 5. Component inventory

Shared between console and portal (Radix primitives, WCAG 2.2 AA):

- `PracticeHeader` — practice name, location line, role/identity chip, platform mark in footer.
- `TaskCard` — one actionable thing + one verb. Used on C-1 and the checklist.
- `ChecklistRow` — label, status token (`DONE` / `WAITING` / `BLOCKED`), action.
- `BandToken` — Standard / Compressed / Urgent / Last chance / Expired / Chase suppressed. Colour is secondary to the word; never colour-only.
- `RuleResultRow` — PASS / WARN / FAIL + citation. Shared by the tester and pre-signature validation.
- `GuardedButton` — disabled-with-reason primitive. Backs every REQ-REG-06 surface.
- `IdentifierChipSet` — renders only the approved six.
- `ArtefactRow` — hash-verified artefact link; renders a failure state if the hash does not match.
- `EventTrail` — vault event list, used by the access log, dispatch audit and attempt history.
- `VerbalFallbackFlag` — risk banner with the sunset date.

Kiosk-only (Expo): `SignaturePad` (vector + raster), `ReadThroughScroller`, `OfflineQueueChip`, `LanguageSwitch`, `ReadAloudControl`, `StaffAssistSheet`.

## 6. Conventions for the UI work

- Hit targets ≥ 44px on kiosk, both orientations; portrait stacks the same field set, never a reduced one.
- No string inline in a component; every one through the string table.
- Secondary text uses `--color-neutral-700` (#5d5d60, 6.0:1 on the ground), not the 55%-ink muted default (3.64:1) — the muted token is only for decorative text at 15px and above. Smallest patient-facing size is 12.5px.
- Colour never the sole carrier of state — bands, rule results and checklist rows all carry a word.
- Every screen that mutates state emits its vault events through the outbox; the UI shows the event trail rather than claiming success on its own.
- Feature-flag every patient-facing screen; the Services Australia registration UI stays behind the D-11 flag and renders "pending mechanism", never a fake success.

## 7. Open items the designs deliberately leave unresolved

- **D-01** Medtech write-back mechanism — `O-1` shows a "Run proof" action against the FR-9.1 mock adapter. No Medtech-specific UI until the mechanism is chosen.
- **D-11** Enduring registration — `E-2` shows `Registration: pending mechanism`.
- Multilingual: `1a` shows the language switch; the four Phase 2 languages need translated artefact layouts (bilingual render) before that screen is final.
